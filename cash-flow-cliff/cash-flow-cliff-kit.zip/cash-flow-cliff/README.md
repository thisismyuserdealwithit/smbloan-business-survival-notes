# Cash-flow Cliff

A fictional 30-day cash-flow teaching game. Release: **25 November 2026**.

Use the daily balance to find a funding gap that a positive month-end total can hide. The three presets are “The late customer”, “The growing order” and “The lumpy costs”. All businesses, dates and amounts are invented; they are not representative business data.

## Open the offline version

Unzip the teaching kit, then double-click `cash-flow-cliff-offline.html`. All calculations and controls work without an internet connection. The guide, CSVs and chart are bundled beside it. External reading and the hosted share link require internet access.

## Run and teach

Serve this directory with a static HTTP server, for example `python -m http.server 8000`, then open `http://localhost:8000/`. The JavaScript modules require an HTTP server rather than opening `index.html` directly as a local file. No build step or external JavaScript library is required.

Open [the game](index.html) or use the [ten-minute educator guide](educator-guide.html). The guide also works as a printed exercise.

## Model conventions

- Day 0 contains opening cash plus any hypothetical extra opening cash.
- Days 1–30 net each day's receipts and payments before calculating the end-of-day balance. Intraday shortfalls are not modelled.
- A deposit moves part of the selected invoice to day 1 and reduces the later receipt by the same amount. It does not create extra revenue.
- A delay moves the remaining invoice payment later. Receipts after day 30 remain pending and are excluded from day 30 cash; they are not assumed lost.
- Extra opening cash is assumed already available. The model does not assume a loan or determine how that money could be obtained.
- Negative balances identify unfunded gaps, not approved credit. Closing cash is not profit.

The baseline late-customer scenario starts at A$5,000, pays A$6,000 on day 7, receives A$15,000 on day 10, then pays A$4,000 on day 14 and A$2,000 on day 21. The minimum is −A$1,000 and the closing balance is A$8,000.

All amounts are final cash movements. Separate tax calculations, interest, financing costs, unlisted obligations and legal deadlines are omitted. This resource is educational and does not provide personalised advice or predict business performance.

## Sources and publisher

[business.gov.au: Set up a cash flow statement](https://business.gov.au/finance/cash-flow/set-up-a-cash-flow-statement), checked 25 November 2026, supports the general cash-flow principles. It does not supply or validate the invented scenarios. [SMB Loan research](https://smbloan.com.au/research/) is separate contextual reading.

Prepared by Joe, AI assistant at Finofin. Published by SMB Loan, a Finofin LTD publication based in Israel. SMB Loan is an information publisher, not a lender or broker, and may receive referral fees from Lend.

## Reuse

Code and accompanying documentation are MIT licensed. Original fictional scenario data are dedicated under CC0 1.0 Universal. See [LICENSE.txt](LICENSE.txt) for scope and terms. No promotional backlink is required. Linked third-party material retains its own rights and terms.
